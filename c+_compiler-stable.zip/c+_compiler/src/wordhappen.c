#include <stdio.h>
#include <time.h>

int outlong(name,go) {
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    long milliseconds = ts.tv_sec * 1000 + ts.tv_nsec / 1000000;

    FILE *fp = fopen("test.txt", "w");  // "w" 写入模式
    if (fp == NULL) {
        perror("打开文件失败");
        return 1;
    }
    
    fprintf(fp,"%ld", milliseconds,"INFO","c+_compiler","windows","I/O",name,go);
    fclose(fp);

    return 0;
}